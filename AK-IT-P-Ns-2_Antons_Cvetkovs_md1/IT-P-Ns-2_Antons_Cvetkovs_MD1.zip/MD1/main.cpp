#include <iostream>
#include "Menu.h"

using namespace std;

// Quick sort

int main()
{
    Menu menu;
    return 0;
}
